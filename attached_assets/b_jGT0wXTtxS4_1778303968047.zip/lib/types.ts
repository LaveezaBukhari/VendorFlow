// User and Auth types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'approver' | 'user';
  tenantId: string;
  createdAt: Date;
}

// Tenant types
export interface Tenant {
  id: string;
  name: string;
  logo?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Vendor types
export interface Vendor {
  id: string;
  tenantId: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  category: string;
  rating: number;
  totalSpent: number;
  status: 'active' | 'inactive' | 'suspended';
  createdAt: Date;
  updatedAt: Date;
}

// Procurement types
export interface PurchaseOrder {
  id: string;
  tenantId: string;
  poNumber: string;
  vendorId: string;
  items: PurchaseOrderItem[];
  totalAmount: number;
  status: 'draft' | 'submitted' | 'approved' | 'rejected' | 'received' | 'cancelled';
  approvalChain: ApprovalStep[];
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  dueDate: Date;
  notes?: string;
}

export interface PurchaseOrderItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
  category: string;
}

export interface ApprovalStep {
  id: string;
  approverName: string;
  approverId: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  approvedAt?: Date;
  order?: number;
}

// Inventory types
export interface InventoryItem {
  id: string;
  tenantId: string;
  sku: string;
  name: string;
  description: string;
  quantity: number;
  reorderLevel: number;
  warehouseLocation: string;
  unitCost: number;
  category: string;
  vendor?: Vendor;
  createdAt: Date;
  updatedAt: Date;
}

export interface Warehouse {
  id: string;
  tenantId: string;
  name: string;
  location: string;
  capacity: number;
  currentUsage: number;
  createdAt: Date;
}

// Audit types
export interface AuditLog {
  id: string;
  tenantId: string;
  userId: string;
  userName: string;
  action: string;
  entityType: string;
  entityId: string;
  changes: Record<string, { before: any; after: any }>;
  ipAddress?: string;
  userAgent?: string;
  timestamp: Date;
}

// Dashboard stats
export interface DashboardStats {
  totalVendors: number;
  activeOrders: number;
  pendingApprovals: number;
  totalSpending: number;
  inventoryValue: number;
  ordersByStatus: Record<string, number>;
}

// Notification types
export interface Notification {
  id: string;
  userId: string;
  type: 'approval_request' | 'order_status' | 'inventory_alert' | 'system';
  title: string;
  message: string;
  read: boolean;
  relatedEntityId?: string;
  createdAt: Date;
}
