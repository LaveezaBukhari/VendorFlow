'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Tenant } from '../types';
import { mockUser, mockTenant } from '../mock-data';

interface AuthContextType {
  user: User | null;
  tenant: Tenant | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('auth_user');
    const storedTenant = localStorage.getItem('auth_tenant');

    if (storedUser && storedTenant) {
      setUser(JSON.parse(storedUser));
      setTenant(JSON.parse(storedTenant));
    }

    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    // Mock login - in production this would call an API
    if (email && password) {
      const userData = { ...mockUser, email };
      setUser(userData);
      setTenant(mockTenant);
      localStorage.setItem('auth_user', JSON.stringify(userData));
      localStorage.setItem('auth_tenant', JSON.stringify(mockTenant));
    }
  };

  const logout = () => {
    setUser(null);
    setTenant(null);
    localStorage.removeItem('auth_user');
    localStorage.removeItem('auth_tenant');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        tenant,
        isLoading,
        isAuthenticated: !!user,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
