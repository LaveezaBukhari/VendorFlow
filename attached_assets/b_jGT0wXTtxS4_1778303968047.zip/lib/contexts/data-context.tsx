'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  Vendor,
  PurchaseOrder,
  InventoryItem,
  Warehouse,
  AuditLog,
  Notification,
  DashboardStats,
} from '../types';
import {
  mockVendors,
  mockPurchaseOrders,
  mockInventory,
  mockWarehouses,
  mockAuditLogs,
  mockNotifications,
} from '../mock-data';

interface DataContextType {
  // Vendors
  vendors: Vendor[];
  addVendor: (vendor: Omit<Vendor, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateVendor: (id: string, vendor: Partial<Vendor>) => void;
  deleteVendor: (id: string) => void;
  getVendor: (id: string) => Vendor | undefined;

  // Purchase Orders
  purchaseOrders: PurchaseOrder[];
  addPurchaseOrder: (
    po: Omit<PurchaseOrder, 'id' | 'createdAt' | 'updatedAt'>
  ) => void;
  updatePurchaseOrder: (id: string, po: Partial<PurchaseOrder>) => void;
  deletePurchaseOrder: (id: string) => void;
  getPurchaseOrder: (id: string) => PurchaseOrder | undefined;

  // Inventory
  inventory: InventoryItem[];
  addInventoryItem: (item: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateInventoryItem: (id: string, item: Partial<InventoryItem>) => void;
  deleteInventoryItem: (id: string) => void;
  getInventoryItem: (id: string) => InventoryItem | undefined;

  // Warehouses
  warehouses: Warehouse[];

  // Audit Logs
  auditLogs: AuditLog[];
  addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp'>) => void;

  // Notifications
  notifications: Notification[];
  markNotificationAsRead: (id: string) => void;
  deleteNotification: (id: string) => void;

  // Dashboard stats
  stats: DashboardStats;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Initialize from localStorage or mock data
  useEffect(() => {
    const storedVendors = localStorage.getItem('vendors');
    const storedPOs = localStorage.getItem('purchase_orders');
    const storedInventory = localStorage.getItem('inventory');
    const storedWarehouses = localStorage.getItem('warehouses');
    const storedAuditLogs = localStorage.getItem('audit_logs');
    const storedNotifications = localStorage.getItem('notifications');

    setVendors(storedVendors ? JSON.parse(storedVendors) : mockVendors);
    setPurchaseOrders(storedPOs ? JSON.parse(storedPOs) : mockPurchaseOrders);
    setInventory(storedInventory ? JSON.parse(storedInventory) : mockInventory);
    setWarehouses(storedWarehouses ? JSON.parse(storedWarehouses) : mockWarehouses);
    setAuditLogs(storedAuditLogs ? JSON.parse(storedAuditLogs) : mockAuditLogs);
    setNotifications(
      storedNotifications ? JSON.parse(storedNotifications) : mockNotifications
    );
  }, []);

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem('vendors', JSON.stringify(vendors));
  }, [vendors]);

  useEffect(() => {
    localStorage.setItem('purchase_orders', JSON.stringify(purchaseOrders));
  }, [purchaseOrders]);

  useEffect(() => {
    localStorage.setItem('inventory', JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem('warehouses', JSON.stringify(warehouses));
  }, [warehouses]);

  useEffect(() => {
    localStorage.setItem('audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    localStorage.setItem('notifications', JSON.stringify(notifications));
  }, [notifications]);

  // Vendor operations
  const addVendor = (vendor: Omit<Vendor, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newVendor: Vendor = {
      ...vendor,
      id: `vendor-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setVendors([...vendors, newVendor]);
  };

  const updateVendor = (id: string, updates: Partial<Vendor>) => {
    setVendors(
      vendors.map((v) =>
        v.id === id
          ? {
              ...v,
              ...updates,
              updatedAt: new Date(),
            }
          : v
      )
    );
  };

  const deleteVendor = (id: string) => {
    setVendors(vendors.filter((v) => v.id !== id));
  };

  const getVendor = (id: string) => vendors.find((v) => v.id === id);

  // Purchase Order operations
  const addPurchaseOrder = (
    po: Omit<PurchaseOrder, 'id' | 'createdAt' | 'updatedAt'>
  ) => {
    const newPO: PurchaseOrder = {
      ...po,
      id: `po-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setPurchaseOrders([...purchaseOrders, newPO]);
  };

  const updatePurchaseOrder = (id: string, updates: Partial<PurchaseOrder>) => {
    setPurchaseOrders(
      purchaseOrders.map((po) =>
        po.id === id
          ? {
              ...po,
              ...updates,
              updatedAt: new Date(),
            }
          : po
      )
    );
  };

  const deletePurchaseOrder = (id: string) => {
    setPurchaseOrders(purchaseOrders.filter((po) => po.id !== id));
  };

  const getPurchaseOrder = (id: string) =>
    purchaseOrders.find((po) => po.id === id);

  // Inventory operations
  const addInventoryItem = (
    item: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'>
  ) => {
    const newItem: InventoryItem = {
      ...item,
      id: `inv-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setInventory([...inventory, newItem]);
  };

  const updateInventoryItem = (id: string, updates: Partial<InventoryItem>) => {
    setInventory(
      inventory.map((item) =>
        item.id === id
          ? {
              ...item,
              ...updates,
              updatedAt: new Date(),
            }
          : item
      )
    );
  };

  const deleteInventoryItem = (id: string) => {
    setInventory(inventory.filter((item) => item.id !== id));
  };

  const getInventoryItem = (id: string) =>
    inventory.find((item) => item.id === id);

  // Audit log operations
  const addAuditLog = (log: Omit<AuditLog, 'id' | 'timestamp'>) => {
    const newLog: AuditLog = {
      ...log,
      id: `audit-${Date.now()}`,
      timestamp: new Date(),
    };
    setAuditLogs([newLog, ...auditLogs]);
  };

  // Notification operations
  const markNotificationAsRead = (id: string) => {
    setNotifications(
      notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications(notifications.filter((n) => n.id !== id));
  };

  // Calculate dashboard stats
  const stats: DashboardStats = {
    totalVendors: vendors.length,
    activeOrders: purchaseOrders.filter((po) => po.status === 'submitted' || po.status === 'draft').length,
    pendingApprovals: purchaseOrders.reduce(
      (sum, po) => sum + po.approvalChain.filter((a) => a.status === 'pending').length,
      0
    ),
    totalSpending: purchaseOrders.reduce((sum, po) => sum + po.totalAmount, 0),
    inventoryValue: inventory.reduce((sum, item) => sum + item.quantity * item.unitCost, 0),
    ordersByStatus: purchaseOrders.reduce(
      (acc, po) => {
        acc[po.status] = (acc[po.status] || 0) + 1;
        return acc;
      },
      {} as Record<string, number>
    ),
  };

  return (
    <DataContext.Provider
      value={{
        vendors,
        addVendor,
        updateVendor,
        deleteVendor,
        getVendor,
        purchaseOrders,
        addPurchaseOrder,
        updatePurchaseOrder,
        deletePurchaseOrder,
        getPurchaseOrder,
        inventory,
        addInventoryItem,
        updateInventoryItem,
        deleteInventoryItem,
        getInventoryItem,
        warehouses,
        auditLogs,
        addAuditLog,
        notifications,
        markNotificationAsRead,
        deleteNotification,
        stats,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
