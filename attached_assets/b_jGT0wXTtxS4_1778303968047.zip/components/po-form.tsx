'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { PurchaseOrder, PurchaseOrderItem } from '@/lib/types';
import { useData } from '@/lib/contexts/data-context';
import { useAuth } from '@/lib/contexts/auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { X, Plus } from 'lucide-react';

interface POFormProps {
  po?: PurchaseOrder;
  isEdit?: boolean;
}

export default function POForm({ po, isEdit = false }: POFormProps) {
  const router = useRouter();
  const { tenant, user } = useAuth();
  const { vendors, addPurchaseOrder, updatePurchaseOrder } = useData();

  const [formData, setFormData] = useState({
    poNumber: po?.poNumber || `PO-${new Date().getFullYear()}-${Math.floor(Math.random() * 10000)}`,
    vendorId: po?.vendorId || '',
    dueDate: po?.dueDate ? new Date(po.dueDate).toISOString().split('T')[0] : '',
    notes: po?.notes || '',
  });

  const [items, setItems] = useState<PurchaseOrderItem[]>(
    po?.items || [
      { id: '1', description: '', quantity: 1, unitPrice: 0, total: 0, category: '' },
    ]
  );

  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleItemChange = (index: number, field: string, value: any) => {
    const newItems = [...items];
    const item = newItems[index];

    if (field === 'quantity') {
      item.quantity = parseFloat(value);
      item.total = item.quantity * item.unitPrice;
    } else if (field === 'unitPrice') {
      item.unitPrice = parseFloat(value);
      item.total = item.quantity * item.unitPrice;
    } else {
      (item as any)[field] = value;
    }

    setItems(newItems);
  };

  const addItem = () => {
    setItems([
      ...items,
      {
        id: `item-${Date.now()}`,
        description: '',
        quantity: 1,
        unitPrice: 0,
        total: 0,
        category: '',
      },
    ]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const totalAmount = items.reduce((sum, item) => sum + item.total, 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (isEdit && po) {
        updatePurchaseOrder(po.id, {
          ...formData,
          items,
          totalAmount,
          dueDate: new Date(formData.dueDate),
        });
      } else {
        addPurchaseOrder({
          poNumber: formData.poNumber,
          vendorId: formData.vendorId,
          items,
          totalAmount,
          status: 'draft',
          approvalChain: [],
          createdBy: user?.id || '',
          dueDate: new Date(formData.dueDate),
          notes: formData.notes,
          tenantId: tenant?.id || '',
        });
      }
      router.push('/dashboard/procurement');
    } catch (error) {
      console.error('Error saving PO:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>{isEdit ? 'Edit Purchase Order' : 'Create Purchase Order'}</CardTitle>
          <CardDescription>
            {isEdit ? 'Update PO details' : 'Create a new purchase order'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="poNumber">PO Number *</Label>
              <Input
                id="poNumber"
                name="poNumber"
                value={formData.poNumber}
                onChange={handleInputChange}
                disabled={isLoading || isEdit}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vendorId">Vendor *</Label>
              <Select
                value={formData.vendorId}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, vendorId: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select vendor" />
                </SelectTrigger>
                <SelectContent>
                  {vendors.map((vendor) => (
                    <SelectItem key={vendor.id} value={vendor.id}>
                      {vendor.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Due Date *</Label>
              <Input
                id="dueDate"
                name="dueDate"
                type="date"
                value={formData.dueDate}
                onChange={handleInputChange}
                disabled={isLoading}
                required
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleInputChange}
              placeholder="Add any additional notes..."
              disabled={isLoading}
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Line Items */}
      <Card>
        <CardHeader>
          <CardTitle>Line Items</CardTitle>
          <CardDescription>Add items to this purchase order</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left text-sm font-medium text-foreground p-2">Description</th>
                  <th className="text-left text-sm font-medium text-foreground p-2">Category</th>
                  <th className="text-right text-sm font-medium text-foreground p-2">Qty</th>
                  <th className="text-right text-sm font-medium text-foreground p-2">Unit Price</th>
                  <th className="text-right text-sm font-medium text-foreground p-2">Total</th>
                  <th className="w-10"></th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={item.id} className="border-b border-border">
                    <td className="p-2">
                      <Input
                        value={item.description}
                        onChange={(e) =>
                          handleItemChange(index, 'description', e.target.value)
                        }
                        placeholder="Item description"
                        disabled={isLoading}
                        className="bg-input"
                      />
                    </td>
                    <td className="p-2">
                      <Input
                        value={item.category}
                        onChange={(e) =>
                          handleItemChange(index, 'category', e.target.value)
                        }
                        placeholder="Category"
                        disabled={isLoading}
                        className="bg-input"
                      />
                    </td>
                    <td className="p-2">
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) =>
                          handleItemChange(index, 'quantity', e.target.value)
                        }
                        disabled={isLoading}
                        className="bg-input text-right"
                        min="0"
                      />
                    </td>
                    <td className="p-2">
                      <Input
                        type="number"
                        value={item.unitPrice}
                        onChange={(e) =>
                          handleItemChange(index, 'unitPrice', e.target.value)
                        }
                        disabled={isLoading}
                        className="bg-input text-right"
                        min="0"
                        step="0.01"
                      />
                    </td>
                    <td className="p-2 text-right text-sm font-medium">
                      ${item.total.toFixed(2)}
                    </td>
                    <td className="p-2">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeItem(index)}
                        disabled={isLoading || items.length === 1}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Button
            type="button"
            variant="outline"
            onClick={addItem}
            disabled={isLoading}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>

          {/* Total */}
          <div className="flex justify-end pt-4">
            <div className="text-lg font-bold text-foreground">
              Total: ${totalAmount.toFixed(2)}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-3">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Saving...' : 'Save Purchase Order'}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => router.back()}
          disabled={isLoading}
        >
          Cancel
        </Button>
      </div>
    </form>
  );
}
