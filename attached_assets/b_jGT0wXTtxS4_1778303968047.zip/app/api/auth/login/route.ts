import { NextRequest, NextResponse } from 'next/server';
import { mockUser, mockTenant } from '@/lib/mock-data';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;

    // Mock authentication
    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    // Simulate successful login
    return NextResponse.json({
      user: { ...mockUser, email },
      tenant: mockTenant,
      token: `mock-token-${Date.now()}`,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
