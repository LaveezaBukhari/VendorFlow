'use client';

import { useData } from '@/lib/contexts/data-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import {
  Package,
  ShoppingCart,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';

const COLORS = ['#3b82f6', '#06b6d4', '#ef4444', '#f59e0b', '#8b5cf6'];

export default function DashboardPage() {
  const {
    stats,
    purchaseOrders,
    vendors,
    inventory,
  } = useData();

  // Prepare data for charts
  const orderStatusData = [
    { name: 'Draft', value: stats.ordersByStatus['draft'] || 0, color: '#94a3b8' },
    { name: 'Submitted', value: stats.ordersByStatus['submitted'] || 0, color: '#3b82f6' },
    { name: 'Approved', value: stats.ordersByStatus['approved'] || 0, color: '#10b981' },
    { name: 'Rejected', value: stats.ordersByStatus['rejected'] || 0, color: '#ef4444' },
    { name: 'Received', value: stats.ordersByStatus['received'] || 0, color: '#06b6d4' },
  ].filter(item => item.value > 0);

  const vendorSpending = vendors.map((vendor) => ({
    name: vendor.name.split(' ')[0],
    spending: vendor.totalSpent,
  }));

  const lowStockItems = inventory.filter(
    (item) => item.quantity <= item.reorderLevel
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Welcome back to VendorFlow</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Vendors</CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.totalVendors}</div>
            <p className="text-xs text-muted-foreground mt-1">Active suppliers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.activeOrders}</div>
            <p className="text-xs text-muted-foreground mt-1">In progress</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <AlertCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.pendingApprovals}</div>
            <p className="text-xs text-muted-foreground mt-1">Awaiting action</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Spending</CardTitle>
            <TrendingUp className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              ${(stats.totalSpending / 1000).toFixed(1)}K
            </div>
            <p className="text-xs text-muted-foreground mt-1">YTD procurement</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Vendor Spending */}
        <Card>
          <CardHeader>
            <CardTitle>Top Vendors by Spending</CardTitle>
            <CardDescription>Your largest suppliers</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={vendorSpending}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: 'none',
                    borderRadius: '6px',
                    color: '#fff',
                  }}
                />
                <Bar dataKey="spending" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Order Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Order Status Distribution</CardTitle>
            <CardDescription>Current purchase order statuses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={orderStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {orderStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Low Stock Items */}
        <Card>
          <CardHeader>
            <CardTitle>Low Stock Alerts</CardTitle>
            <CardDescription>{lowStockItems.length} items below reorder level</CardDescription>
          </CardHeader>
          <CardContent>
            {lowStockItems.length === 0 ? (
              <p className="text-sm text-muted-foreground">All inventory levels are healthy</p>
            ) : (
              <div className="space-y-3">
                {lowStockItems.slice(0, 5).map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                    <div>
                      <p className="text-sm font-medium text-foreground">{item.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.quantity} / {item.reorderLevel} units
                      </p>
                    </div>
                    <Badge variant="destructive">Low Stock</Badge>
                  </div>
                ))}
              </div>
            )}
            <Link href="/dashboard/inventory">
              <Button variant="outline" className="w-full mt-4">
                View Inventory
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Latest purchase orders</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {purchaseOrders.slice(0, 5).map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-accent/50">
                  <div>
                    <p className="text-sm font-medium text-foreground">{order.poNumber}</p>
                    <p className="text-xs text-muted-foreground">
                      ${order.totalAmount.toLocaleString()}
                    </p>
                  </div>
                  <Badge
                    variant={
                      order.status === 'approved'
                        ? 'default'
                        : order.status === 'submitted'
                          ? 'secondary'
                          : 'outline'
                    }
                  >
                    {order.status}
                  </Badge>
                </div>
              ))}
            </div>
            <Link href="/dashboard/procurement">
              <Button variant="outline" className="w-full mt-4">
                View All Orders
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
