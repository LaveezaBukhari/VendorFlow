'use client';

import POForm from '@/components/po-form';

export default function NewPOPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">New Purchase Order</h1>
        <p className="text-muted-foreground mt-1">Create a new purchase order</p>
      </div>
      <POForm />
    </div>
  );
}
