'use client';

import { useParams } from 'next/navigation';
import { useData } from '@/lib/contexts/data-context';
import POForm from '@/components/po-form';
import { Card, CardContent } from '@/components/ui/card';

export default function EditPOPage() {
  const params = useParams();
  const { purchaseOrders } = useData();
  const poId = params.id as string;
  const po = purchaseOrders.find((p) => p.id === poId);

  if (!po) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-foreground">Edit Purchase Order</h1>
        <Card>
          <CardContent className="pt-6">
            <p className="text-muted-foreground">Purchase order not found</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (po.status !== 'draft') {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-foreground">Edit Purchase Order</h1>
        <Card>
          <CardContent className="pt-6">
            <p className="text-muted-foreground">
              You can only edit draft purchase orders
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Edit Purchase Order</h1>
        <p className="text-muted-foreground mt-1">{po.poNumber}</p>
      </div>
      <POForm po={po} isEdit />
    </div>
  );
}
