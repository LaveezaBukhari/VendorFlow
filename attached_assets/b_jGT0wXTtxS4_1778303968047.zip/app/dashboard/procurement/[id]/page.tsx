'use client';

import { useParams, useRouter } from 'next/navigation';
import { useData } from '@/lib/contexts/data-context';
import { useAuth } from '@/lib/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import Link from 'next/link';
import { ArrowLeft, CheckCircle, XCircle, Clock } from 'lucide-react';
import { useState } from 'react';

export default function PODetailPage() {
  const router = useRouter();
  const params = useParams();
  const poId = params.id as string;
  const { purchaseOrders, updatePurchaseOrder, vendors } = useData();
  const { user } = useAuth();

  const po = purchaseOrders.find((p) => p.id === poId);
  const vendor = po ? vendors.find((v) => v.id === po.vendorId) : null;

  const [rejectionReason, setRejectionReason] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!po || !vendor) {
    return (
      <div className="space-y-6">
        <Button
          variant="ghost"
          onClick={() => router.back()}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Card>
          <CardContent className="pt-6">
            <p className="text-muted-foreground">Purchase order not found</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleApprove = async () => {
    setIsProcessing(true);
    // Check if there are more approvers in the chain
    const pendingApprovals = po.approvalChain.filter((a) => a.status === 'pending');
    const nextApprover = pendingApprovals[0];

    if (nextApprover) {
      // Mark current approval as approved
      const updatedChain = po.approvalChain.map((a) =>
        a.id === nextApprover.id
          ? { ...a, status: 'approved' as const, approvedAt: new Date() }
          : a
      );
      updatePurchaseOrder(po.id, {
        approvalChain: updatedChain,
        status: updatedChain.some((a) => a.status === 'pending')
          ? 'submitted'
          : 'approved',
      });
    }
    setIsProcessing(false);
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      alert('Please provide a rejection reason');
      return;
    }
    setIsProcessing(true);
    const pendingApprovals = po.approvalChain.filter((a) => a.status === 'pending');
    const nextApprover = pendingApprovals[0];

    if (nextApprover) {
      const updatedChain = po.approvalChain.map((a) =>
        a.id === nextApprover.id
          ? {
              ...a,
              status: 'rejected' as const,
              rejectionReason: rejectionReason,
            }
          : a
      );
      updatePurchaseOrder(po.id, {
        approvalChain: updatedChain,
        status: 'rejected',
      });
    }
    setIsProcessing(false);
  };

  const handleSubmitForApproval = async () => {
    setIsProcessing(true);
    if (po.approvalChain.length === 0) {
      // Create mock approval chain
      updatePurchaseOrder(po.id, {
        status: 'submitted',
        approvalChain: [
          {
            id: `approval-${Date.now()}`,
            approverName: 'Manager',
            approverId: 'manager-1',
            status: 'pending',
            order: 1,
          },
        ],
      });
    } else {
      updatePurchaseOrder(po.id, { status: 'submitted' });
    }
    setIsProcessing(false);
  };

  const statusColors: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
    draft: 'outline',
    submitted: 'secondary',
    approved: 'default',
    rejected: 'destructive',
    received: 'default',
    cancelled: 'destructive',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl font-bold text-foreground">{po.poNumber}</h1>
          <p className="text-muted-foreground mt-1">
            {vendor.name} · Created{' '}
            {new Date(po.createdAt).toLocaleDateString()}
          </p>
        </div>
        <div className="flex gap-2 items-start">
          <Badge variant={statusColors[po.status]}>
            {po.status}
          </Badge>
          {po.status === 'draft' && (
            <Link href={`/dashboard/procurement/${po.id}/edit`}>
              <Button size="sm">Edit</Button>
            </Link>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Line Items */}
          <Card>
            <CardHeader>
              <CardTitle>Line Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Description</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {po.items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.description}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell className="text-right">{item.quantity}</TableCell>
                        <TableCell className="text-right">
                          ${item.unitPrice.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          ${item.total.toFixed(2)}
                        </TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="bg-muted/50">
                      <TableCell colSpan={4} className="text-right font-bold">
                        Total:
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        ${po.totalAmount.toFixed(2)}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Approval Chain */}
          <Card>
            <CardHeader>
              <CardTitle>Approval Chain</CardTitle>
              <CardDescription>
                {po.approvalChain.length === 0
                  ? 'No approvals required'
                  : `${po.approvalChain.filter((a) => a.status === 'approved').length} of ${po.approvalChain.length} approved`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {po.approvalChain.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  This purchase order is ready to be submitted for approval.
                </p>
              ) : (
                <div className="space-y-3">
                  {po.approvalChain.map((approval, index) => (
                    <div
                      key={approval.id}
                      className="flex items-center gap-4 p-3 rounded-lg border border-border"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-foreground">
                          {approval.approverName}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Step {index + 1}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {approval.status === 'approved' ? (
                          <>
                            <CheckCircle className="h-5 w-5 text-green-500" />
                            <span className="text-sm font-medium">Approved</span>
                          </>
                        ) : approval.status === 'rejected' ? (
                          <>
                            <XCircle className="h-5 w-5 text-destructive" />
                            <span className="text-sm font-medium text-destructive">
                              Rejected
                            </span>
                          </>
                        ) : (
                          <>
                            <Clock className="h-5 w-5 text-yellow-500" />
                            <span className="text-sm font-medium">Pending</span>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Notes */}
          {po.notes && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{po.notes}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* PO Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div>
                <p className="text-muted-foreground">Vendor</p>
                <Link href={`/dashboard/vendors/${vendor.id}`}>
                  <p className="font-medium text-primary hover:underline">
                    {vendor.name}
                  </p>
                </Link>
              </div>
              <div>
                <p className="text-muted-foreground">Status</p>
                <p className="font-medium text-foreground capitalize">{po.status}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Total Amount</p>
                <p className="text-lg font-bold text-foreground">
                  ${po.totalAmount.toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Due Date</p>
                <p className="font-medium text-foreground">
                  {new Date(po.dueDate).toLocaleDateString()}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Approval Actions */}
          {po.status === 'draft' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <Button
                  className="w-full"
                  onClick={handleSubmitForApproval}
                  disabled={isProcessing}
                >
                  Submit for Approval
                </Button>
              </CardContent>
            </Card>
          )}

          {po.status === 'submitted' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Review</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="rejection-reason" className="text-xs">
                    Rejection Reason (if applicable)
                  </Label>
                  <Textarea
                    id="rejection-reason"
                    placeholder="Provide reason for rejection..."
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    className="text-sm"
                    rows={3}
                    disabled={isProcessing}
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="default"
                    size="sm"
                    className="flex-1"
                    onClick={handleApprove}
                    disabled={isProcessing}
                  >
                    Approve
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    className="flex-1"
                    onClick={handleReject}
                    disabled={isProcessing}
                  >
                    Reject
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
