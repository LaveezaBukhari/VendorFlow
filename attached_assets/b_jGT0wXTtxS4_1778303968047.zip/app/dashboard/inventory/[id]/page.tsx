'use client';

import { useParams, useRouter } from 'next/navigation';
import { useData } from '@/lib/contexts/data-context';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

export default function InventoryDetailPage() {
  const router = useRouter();
  const params = useParams();
  const { inventory } = useData();
  const itemId = params.id as string;
  const item = inventory.find((i) => i.id === itemId);

  if (!item) {
    return (
      <div className="space-y-6">
        <Button variant="ghost" onClick={() => router.back()} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Card>
          <CardContent className="pt-6">
            <p className="text-muted-foreground">Item not found</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const valueAtRisk = item.quantity * item.unitCost;
  const isLowStock = item.quantity <= item.reorderLevel;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <Button variant="ghost" onClick={() => router.back()} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl font-bold text-foreground">{item.name}</h1>
          <p className="text-muted-foreground mt-1">{item.sku}</p>
        </div>
        <Link href={`/dashboard/inventory/${item.id}/edit`}>
          <Button>Edit</Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Current Stock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{item.quantity}</div>
            <p className="text-xs text-muted-foreground mt-1">units in stock</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Reorder Level</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{item.reorderLevel}</div>
            <p className={`text-xs mt-1 ${isLowStock ? 'text-destructive' : 'text-green-500'}`}>
              {isLowStock ? 'Below minimum' : 'Adequate supply'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Stock Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">
              ${valueAtRisk.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground mt-1">current value</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div>
              <p className="text-muted-foreground">Category</p>
              <p className="font-medium text-foreground">{item.category}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Unit Cost</p>
              <p className="font-medium text-foreground">${item.unitCost.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Warehouse Location</p>
              <p className="font-medium text-foreground">{item.warehouseLocation}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Description</p>
              <p className="font-medium text-foreground">{item.description}</p>
            </div>
          </CardContent>
        </Card>

        {item.vendor && (
          <Card>
            <CardHeader>
              <CardTitle>Supplier</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <Link href={`/dashboard/vendors/${item.vendor.id}`}>
                <p className="font-medium text-primary hover:underline">
                  {item.vendor.name}
                </p>
              </Link>
              <div>
                <p className="text-muted-foreground">Email</p>
                <a
                  href={`mailto:${item.vendor.email}`}
                  className="text-primary hover:underline"
                >
                  {item.vendor.email}
                </a>
              </div>
              <div>
                <p className="text-muted-foreground">Phone</p>
                <p className="font-medium text-foreground">{item.vendor.phone}</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
